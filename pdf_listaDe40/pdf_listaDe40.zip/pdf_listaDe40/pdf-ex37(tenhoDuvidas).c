#include <stdio.h>
int main()
{
    int horaC, minC, horaP, minP, minT, minF, horaF, horaT, tarifa, preco;

    printf("Digite o horario de chegada:  ");
    scanf("%d %d", &horaC, &minC);
    printf("Digite o horario de partida:  ");
    scanf("%d %d", &horaP, &minP);

    if (horaC > horaP)
    {
        horaP = horaP + 24;
    }
    if (minC > minP)
    {
        minP = minP + 60;
        horaP = horaP - 1;
    }

    minF = minP - minC;
    horaF = horaP - horaC;

    if (horaF >= 1)
    {
        if (minF >= 1)
        {
            printf("O carro ficou estacionado durante %d horas e %d minutos.", horaF, minF);
        }
        else
        {
            printf("O carro ficou estacionado durante %d horas.", horaF);
        }
    }
    else
    {
        printf("O carro ficou estacionado durante %d minutos.", minF);
    }

    // Define valores:
    minT = (horaF * 60) + minF;

    if (minT <= 120)
    {
        if (minT <= 60)
        {
            tarifa = 1.00;
            printf("Preco total: R$%d.", preco);
        }
        else
        {
            preco = 2;
            printf("Preco total: R$%d.", preco);
        }
    }
    if (minT <= 240)
    {
        if (minT <= 180)
        {
            preco = 2 + 1.40;
            printf("Preco total: R$%d.", preco);
        }
        else
        {
            preco = 2 + (1.40 * 2);
            printf("Preco total: R$%d.", preco);
        }
    }
    else
    {
        horaT = minT;
        preco = 4.40 + ((horaT - 4) * 2);
        printf("Preco total: R$%d.", preco);
    }

    return 0;
}

